<?php
/**
 * Verify the exact manifest bytes before trusting any ZIP metadata.
 * The release public key is provisioned separately from update archives.
 */
function ekVerifyUpdateManifest(string $manifest, string $signature, string $publicKey): bool {
    if ($manifest === '' || strlen($manifest) > 65536 ||
        $signature === '' || strlen($signature) > 2048 || $publicKey === '' ||
        !function_exists('openssl_verify')) {
        return false;
    }
    $decoded = base64_decode(trim($signature), true);
    if ($decoded === false || $decoded === '') {
        return false;
    }
    $key = openssl_pkey_get_public($publicKey);
    return $key !== false && openssl_verify($manifest, $decoded, $key, OPENSSL_ALGO_SHA256) === 1;
}

function ekUpdatePublicKey(): string {
    return <<<'PEM'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAssQ8YY8sFaEyVekUUKVj
vqeaMFpmwgbpgTH7mARNJGFfBBbZX1/QMpFd64auWdW2ZGMEbnOC+h3WZ8na7r+R
OkW5GMK/+wK/VqrEX38Nah0RrSYnYycqBawLnbeg2NMDL2g9O4QSZpkjk3wLlAjH
aZOVaBxSmEugRHxf6BrUNTEbxxHmqObi4Yo6mIlRaaFBXp9LRzxrmJvY6rZDZFUs
pwEbpP85TAVSrImUr9iDipedb5uv78BPiXcFtGt7JPXMSjtXmCOQhASTDl2nR911
m+AQ1FnfP6pI97YKOIbPdTbWoFyKXCyAFqlA1Xea8fdR49s+2XrgQPeufRgwqoFo
+4CTYIoPqu/NYRoyRCo6xxzzygDNjrhJJJmXD8GeksRz/qlgHoAmLh26FMVdYwCA
DciXEIm0Sl0Hv5bU+TQUr1ALKezTx9xDu/fRe9Zepto8YROw5AJVaLduNRGnhV5P
ZJMW1baR/8uKkHeYQVVvyET+hSHzmY3Uig+P1/BVl0R3AgMBAAE=
-----END PUBLIC KEY-----
PEM;
}
